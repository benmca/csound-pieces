/* FM C file generated Fri 14-Aug-98 at 8:14 CDT  by CLM (version: 27-Apr-98) */
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif
#include <stdio.h>
#include <stdlib.h>
#include <math.h>




#ifndef CLM_C_INSTRUMENT

#ifndef LONG_INT_P
  #define LONG_INT_P 0
#endif

#define one_pi 3.141592653589793
#define two_pi 6.283185307179586
#define minus_two_pi -6.283185307179586
#define half_pi 1.5707963267948966
#define three_half_pi 4.71238898038469
#define inverse_pi 0.15915494309189535
#define clm_sndfix 32768.0
#define clm_sndflt 0.000030517578
#define io_fd 0
#define io_chans 1
#define io_size 2
#define io_beg 3
#define io_end 4
#define io_bufsiz 5
#define io_data_start 6
#define io_data_end 7
#define io_open_index 8
#define io_dir 9
#define io_loc 10
#define io_hdr_end 11
#define io_incr 12
#define io_dats 13

#define CLM_FATAL_WRITE_ERROR 7
#define ERROR_C 10
#define BREAK_C 11
#define FUNCTION_C 12
#define SIGINT_C 13
#define CLM_REVERB_CHANNEL 64

#ifndef MACOS
#ifndef CLM_SIGFNC_DEFINED
#define CLM_SIGFNC_DEFINED
  #ifndef RETSIGTYPE 
    #define RETSIGTYPE void
  #endif
  typedef RETSIGTYPE sigfnc(int);
#endif
#endif

/* prototypes for all C functions that might be externally visible to CLM instruments */
  void clm_printf(char *str);
  int clm_open_read(char *arg);
  int clm_open_write(char *arg);
  int clm_create(char *arg);
  int clm_reopen_write(char *arg);
  void clm_close(int fd);
  long clm_seek(int tfd, long offset, int origin);
  int clm_write_floats(int fd,int n,float *arr);
  int clm_read_floats(int fd,int n,float *arr);
  int clm_read_swapped_floats(int fd,int n,float *arr);
  int clm_read_ints(int fd,int n,int *arr);
  int clm_read_swapped_ints(int fd,int n,int *arr);
  void clm_seek_floats(int fd,int n);
  void clm_seek_bytes(int fd,int n);
  void clm_file_reset(int loc0, int *io, int *datai);
  void clm_full_file_reset(int loc, int *io, int *datai);
  int clm_read_any(int tfd, int beg, int chans, int nints, int **bufs, int *cm);
#ifndef MACOS
  sigfnc *clm_signal(int signo, sigfnc *fnc);
#endif
  void c_newline(void);
  void c_init_sine (void);
  float c_sin_lookup(float phase);
  float c_frandom(float amp);
  void c_fft_window(float *rl, float *win, int size);
  void c_clear_block(float *rl, int size);
  void c_blti(int *arr0, int beg, int *arr1, int len);
  void c_bltf(float *arr0, int beg, float *arr1, int len);
  int c_gcd(int a, int b);
  int c_lcm(int a, int b);
  float c_table_interp (float *fn, float xx, int len);
  float c_table_lookup (int *tbl, float *datar, float fm);
  float c_direct_flt (int m, float input, float *flt_a, float *flt_b, float *flt_d);
  float c_lattice_flt (int m, float input, float *flt_a, float *flt_b, float *flt_d);
  float c_ladder_flt (int m, float input, float so, float *flt_a, float *flt_b, float *flt_c, float *flt_d);
  int c_y_or_n_p (void);
  int c_yes_or_no_p (void);
  void c_fft (float* rl, float* im, int n, int isign, int ipow);
  void convolve (float* rl1, float* rl2, int n, int ipow);
  void c_fht (int powerOfFour, float *array);
  void c_fft_magnitude(float *rl, float *im, int size);
  void c_spectrum(float *rdat, float *idat, float *window, int n, int type);
  void c_env_restart (float *ef, int *ei, float *data);
  float c_env (float *ef, int *ei, float *data);
  double jv_exp(double x);
  float c_run_block (int *blk, float *fblk, float *buf);
  void c_base_run_block (int *blk, float *fblk, float *buf);
  float c_readin (int *rd, int *io, int *datai);
  float c_src(int *rd, int *rio, int *datai, float *srf, int *sri, float *data, float fm, float *sinc, float *fblk, float *buf);
  float c_spd (int *rddat, int *spidat, float *spfdat, int *io, int *datai, float *b, float *fblk, float *buf);
  void set_expansion_triggers (int *rddat, int *spidat, float *fblk, float *buf);
  void add_one_segment (int *rd, int *spidat, float *spfdat, int *rio, int *datai, float *b, float *buf);
  float c_fft_filter (int *rddat, int *io, int *iobufs, int *runblk, float *fblk, int *fftdat,
		      float *runbuf, float *datar, float *datai, float *fenv, float *rfblk, float *rbuf);
  void c_convolve (char *fname, 
                   int filec, int filehdr,
                   int filterc, int filterhdr, int filtersize,
                   int start, int fftsize, int ipow, int chans, int chan);
  float c_convolve_or_readin (int *rddat, int *io, int *iobufs, int *runblk, float *fblk, int *fftdat,
			      float *runbuf, float *datar, float *datai, float *filtr, int filti, float *rfblk, float *rbuf);
  void lpc_out(int order,float *coeffs,float *Zs,float *values);
  void lpc_in(int order, int block_size, int hop_size, float *data, float *out_data, float *values);
  void load_one_sine (float partial, float amp, float *table, int table_size, float phase);
  void initialize_ins (int beg_sample, int end_sample, int out_adr, int rev_adr,
	  	       int *datai, int leni, float *datar, int lenr, 
		       int (*loop_function)());

  int get_clm_var_table_size (void);
  int get_int_clm_var (int index, int type);
  int get_int_aref_clm_var (int index, int arrind, int type);
  int set_int_clm_var (int index, int val, int type);
  int set_int_aref_clm_var (int index, int arrind, int val, int type);
  float get_float_clm_var (int index, int type);
  float get_float_aref_clm_var (int index, int arrind, int type);
  float set_float_clm_var (int index, float val, int type);
  float set_float_aref_clm_var (int index, int arrind, float val, int type);
#ifdef MCL_PPC
  void mcl_get_float_clm_var (int index, int type, float *df);
  void mcl_get_float_aref_clm_var (int index, int arrind, int type, float *df);
  void mcl_set_float_clm_var (int index, float *val, int type);
  void mcl_set_float_aref_clm_var (int index, int arrind, float *val, int type);
  void clm_break(void);
  void clm_error(void);
  void clm_funcall(char *str);
#endif
#if LONG_INT_P
  int *delist_ptr(int arr);
  int list_ptr(int *arr);
  int incarray(int arr_1, int i, int val);
  int getarray(int arr_1, int i);
#endif
#if defined(SGI) || defined(LINUX)
  int write_snd_fifo(char *buf, int len);
  void make_sound_file(char *filename, float *data, int len, int srate, int channels);
  float c_control (int n);
  float c_set_control (int n, float val);
#endif

#endif


#ifndef CLM_C_INSTRUMENT
  #define CLM_C_INSTRUMENT 1
#endif




#pragma export on
int clm_fm0 (int clm_beg, int clm_end, float *clm_float_data, int *clm_int_data)
{
  /* declarations. The DSP_nnnn variables are compiler-generated temporaries */
  #define cl_true 7654321
  #define cl_false 1234567
  int I;
  float DSP_697,DSP_693,DSP_696,DSP_694,DSP_698,DSP_695;
  int *CAR,*AMPF,*LOC,*DEVF,*MOD;
  float *DSP_692;
  int **out_IO_dats_ = NULL,**rev_IO_dats_ = NULL,**in_IO_dats_ = NULL;
  int *cur_IO_out_,*cur_IO_rev_, *clm_outA_,*clm_outB_,*clm_revA_,*cur_IO_in_,*clm_inA_,*clm_inB_;
  int cur_IO_out_chans_,cur_IO_rev_chans_,cur_IO_in_chans_,ptr_i_;
  if (clm_int_data[2] != cl_false) {  /* preset main IO pointers */
    cur_IO_out_ = (int *)(clm_int_data+clm_int_data[2]);
    cur_IO_out_chans_ = cur_IO_out_[io_chans];
#if LONG_INT_P
    out_IO_dats_ = (int **)calloc(cur_IO_out_chans_,sizeof(int *));
    for (ptr_i_=0;ptr_i_<cur_IO_out_chans_;ptr_i_++) out_IO_dats_[ptr_i_] = delist_ptr(clm_int_data[cur_IO_out_[io_dats+0]+ptr_i_]);
#else
    out_IO_dats_ = (int **)(clm_int_data+cur_IO_out_[io_dats+0 /* aref_block */]);
#endif
    clm_outA_ = (int *)(out_IO_dats_[0]);
    if (cur_IO_out_chans_>1) clm_outB_ = (int *)(out_IO_dats_[1]); else clm_outB_=NULL;}
  else {cur_IO_out_ = NULL; clm_outA_=NULL; clm_outB_=NULL;}
  if (clm_int_data[3] != cl_false) {
    cur_IO_rev_ = (int *)(clm_int_data+clm_int_data[3]);
    cur_IO_rev_chans_ = cur_IO_rev_[io_chans];
#if LONG_INT_P
    rev_IO_dats_ = (int **)calloc(cur_IO_rev_chans_,sizeof(int *));
    for (ptr_i_=0;ptr_i_<cur_IO_rev_chans_;ptr_i_++) rev_IO_dats_[ptr_i_] = delist_ptr(clm_int_data[cur_IO_rev_[io_dats+0]+ptr_i_]);
#else
    rev_IO_dats_ = (int **)(clm_int_data+cur_IO_rev_[io_dats+0 /* aref_block */]);
#endif
    clm_revA_ = (int *)(rev_IO_dats_[0]);}
  else {cur_IO_rev_ = NULL; clm_revA_=NULL;}
  if (clm_int_data[4] != cl_false) {
    cur_IO_in_ = (int *)(clm_int_data+clm_int_data[4]);
    cur_IO_in_chans_ = cur_IO_in_[io_chans];
    #if LONG_INT_P
    in_IO_dats_ = (int **)calloc(cur_IO_in_chans_,sizeof(int *));
    for (ptr_i_=0;ptr_i_<cur_IO_in_chans_;ptr_i_++) in_IO_dats_[ptr_i_] = delist_ptr(clm_int_data[cur_IO_in_[io_dats+0]+ptr_i_]);
#else
    in_IO_dats_ = (int **)(clm_int_data+cur_IO_in_[io_dats+0 /* aref_block */]);
#endif
    clm_inA_ = (int *)(in_IO_dats_[0]);
    if (cur_IO_in_chans_>1) clm_inB_ = (int *)(in_IO_dats_[1]); else clm_inB_=NULL;}
  else {cur_IO_in_ = NULL; clm_inA_=NULL; clm_inB_=NULL;}
  /* initializations. All Run loop entities are passed through clm_int_data and clm_float_data */
  MOD = (int *)(clm_int_data+7);       /* mod */
  DEVF = (int *)(clm_int_data+9);       /* devf */
  LOC = (int *)(clm_int_data+37);       /* loc */
  AMPF = (int *)(clm_int_data+24);       /* ampf */
  CAR = (int *)(clm_int_data+22);       /* car */
  if (clm_beg > clm_end) return(1);
  I = clm_beg;        /* pass counter */
  goto SAMPLE_LOOP_INIT;       /* pick up stuff we missed in the first pass */

SAMPLE_LOOP_BEGIN:
  if (I > clm_end) goto RUN_ALL_DONE;
  DSP_694 = c_env((float *)(clm_float_data+AMPF[0]),(int *)(AMPF+1),(float *)(clm_float_data+AMPF[7]));       /* (env ampf) */
  DSP_697 = c_env((float *)(clm_float_data+DEVF[0]),(int *)(DEVF+1),(float *)(clm_float_data+DEVF[7]));       /* (env devf) */
  DSP_698 = c_sin_lookup(clm_float_data[MOD[0]+1]);       /* (oscil mod) */
  clm_float_data[MOD[0]+1] += clm_float_data[MOD[0]];
  MOD[1]++; if ((MOD[1])>1000) {MOD[1] = 0; clm_float_data[MOD[0]+1] = fmod(clm_float_data[MOD[0]+1],two_pi);}
  DSP_696 = (DSP_697) * (DSP_698);
  DSP_695 = c_sin_lookup(clm_float_data[CAR[0]+1]);       /* (oscil car DSP_696) */
  clm_float_data[CAR[0]+1] += (clm_float_data[CAR[0]] + DSP_696);
  CAR[1]++; if ((CAR[1])>1000) {CAR[1] = 0; clm_float_data[CAR[0]+1] = fmod(clm_float_data[CAR[0]+1],two_pi);}
  DSP_693 = (DSP_694) * (DSP_695);
  /* (locsig loc I DSP_693) */
  if ((I) >= 0)
  { int k,oloc;
    if ((I < cur_IO_out_[io_beg]) || (I > cur_IO_out_[io_end])) clm_full_file_reset(I,cur_IO_out_,clm_int_data);
    oloc = (int)(I - cur_IO_out_[io_beg]);
        clm_outA_[oloc] += (int)((DSP_693)*DSP_692[0]);
    if (clm_outB_) clm_outB_[oloc] += (int)((DSP_693)*DSP_692[1]);
    if (cur_IO_out_chans_>2) {
      for (k=2;k<cur_IO_out_chans_;k++) out_IO_dats_[k][oloc] += (int)((DSP_693)*DSP_692[k]);}
    if (cur_IO_rev_){
      if ((I < cur_IO_rev_[io_beg]) || (I > cur_IO_rev_[io_end])) clm_full_file_reset(I,cur_IO_rev_,clm_int_data);
      oloc = (int)(I - cur_IO_rev_[io_beg]);
      clm_revA_[oloc] += (int)((DSP_693)*(clm_float_data[LOC[8]]));
      if (cur_IO_rev_chans_>1) {
      for (k=1;k<cur_IO_rev_chans_;k++)
          rev_IO_dats_[k][oloc] += (int)((DSP_693)*(clm_float_data[LOC[8]+k]));}}}
  I++;       /* increment pass counter and loop */

  goto SAMPLE_LOOP_BEGIN;

SAMPLE_LOOP_INIT:
  /* pick up initializations that were not noticed until the code was already out */
  DSP_692 = (float *)(clm_float_data+LOC[2]); /* initialize ptr to locsig scaler array */
  if (cur_IO_out_ == NULL) {clm_printf("locsig with no output file?"); goto RUN_ALL_DONE;}
  if ((clm_beg < cur_IO_out_[io_beg]) || (clm_beg > cur_IO_out_[io_end])) clm_file_reset(clm_beg,cur_IO_out_,clm_int_data);
  if (cur_IO_rev_)
    {if ((clm_beg < cur_IO_rev_[io_beg]) || (clm_beg > cur_IO_rev_[io_end])) clm_file_reset(clm_beg,cur_IO_rev_,clm_int_data);}
  goto SAMPLE_LOOP_BEGIN;

  /* end of run loop -- update io data for lisp */
RUN_ALL_DONE:
  if (cur_IO_out_)
    {if (cur_IO_out_[io_data_end] < (I - cur_IO_out_[io_beg])) cur_IO_out_[io_data_end] = (I - cur_IO_out_[io_beg]);
     if (cur_IO_out_[io_data_end] >= cur_IO_out_[io_bufsiz]) cur_IO_out_[io_data_end] = (cur_IO_out_[io_bufsiz]-1);}
  if (cur_IO_rev_)
    {if (cur_IO_rev_[io_data_end] < (I - cur_IO_rev_[io_beg])) cur_IO_rev_[io_data_end] = (I - cur_IO_rev_[io_beg]);
     if (cur_IO_rev_[io_data_end] >= cur_IO_rev_[io_bufsiz]) cur_IO_rev_[io_data_end] = (cur_IO_rev_[io_bufsiz]-1);}
#if LONG_INT_P
  if (out_IO_dats_) free(out_IO_dats_); if (rev_IO_dats_) free(rev_IO_dats_); if (in_IO_dats_) free(in_IO_dats_);
#endif

  return(1);
}

#pragma export off
